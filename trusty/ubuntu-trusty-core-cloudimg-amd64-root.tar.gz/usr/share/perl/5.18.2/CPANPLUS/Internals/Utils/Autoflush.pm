package CPANPLUS::Internals::Utils::Autoflush;
use deprecate;

use vars qw[$VERSION];
$VERSION = "0.9135";

BEGIN { $|++ };

1;
